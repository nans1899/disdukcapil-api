<!DOCTYPE html>
<html>
<head>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}

</style>
</head>
<body>

<h2 style="text-align: center">Portal Tableau - Dukcapil</h2>

<table>
    <tr>
        
        <th>Name</th>
        <th>Site</th>
        <th>Roles</th>
        <th>Hide</th>
        <th>Number</th>
    </tr>
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->site_id == 0 ? '-' : $item->site_id); ?></td>
            <td>
                <?php $__currentLoopData = $item->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($roles->name); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td><?php echo e($item->hide == 0 ? 'Tampilkan' : 'Sembunyikan'); ?></td>
            <td><?php echo e($item->no); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</body>
</html>

<?php /**PATH E:\Laragon\www\rifkiproject-pildacil\resources\views/menuexport.blade.php ENDPATH**/ ?>