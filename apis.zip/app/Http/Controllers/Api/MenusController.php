<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\MenusResource;
use App\Models\Menus;
use App\Models\Roles;
class MenusController extends Controller
{

    public function allMenus(){
        $menus = Menus::with('childs.childs.childs')->where('parent_id', 0)->whereHas('menuroles', function ($q){
            $q->where('roles_id', Auth()->user()->role_id);
        })->where('hide', 0)->get();

        return response()->json($menus);
    }

    public function getMenus(){
        $menus = Menus::with('childs')->where('parent_id', 0)->whereHas('menuroles', function ($q){
            $q->where('roles_id', Auth()->user()->role_id);
        })->orderBy('no', 'asc')->where('hide', 0)->get();
        return MenusResource::collection($menus);
    }

    public function getSubmenus($id){
        $menus = null;
        if ($id) {
            # code...
            $menus = Menus::with('childs')->where('parent_id', $id)->whereHas('menuroles', function ($q){
                $q->where('roles_id',Auth()->user()->role_id);
            })->orderBy('no', 'asc')->get();

            if (empty($menus->toArray())) {
                $server =  env('DUK_HOST');
                $ticket = $this->getTicket();

                return response()->json([
                    'urlview'   => route('viewdashboard', $id),
                    'ticket'    => $ticket
                ]);
            }
        }
        return MenusResource::collection($menus->where('hide', 0));

        // $menus = Menus::with('childs')->where('parent_id', $id)->whereHas('roles', function ($q) {
        //     $q->where('roles_id', 2);
        // })->where('hide', 0)->get();

        // return response()->json($menus);
    }

    public function getRole(){
        $roles =  Roles::with('menus')->get();
        return MenusResource::collection($roles);
    }

    public function getTicket(){
        $user       =  Auth()->user()->name;
        $server     =  env('DUK_HOST');
        $targetsite =  null;

        //extract data from the post
        // extract($_POST);

        //set POST variables
        $url = $server.'/trusted';

        if($targetsite != "" && $targetsite != null)
        {
            $fields_string ='username='.$user.'&target_site='.$targetsite;
        }
        else
        {
            $fields_string ='username='.$user;
        }

        // open connection
        $ch = curl_init();

        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_POST => 1,
            CURLOPT_POSTFIELDS => $fields_string,
            CURLOPT_RETURNTRANSFER => 1
        ));

        $response = curl_exec($ch);
        $err = curl_error($ch);

        curl_close($ch);

        return $response;
    }
}
