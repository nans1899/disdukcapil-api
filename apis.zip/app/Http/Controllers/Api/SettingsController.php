<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\Accounts;
use App\Models\Menus;
use App\Models\Roles;
use App\Models\Settings;
use App\Repositories\UserRepository;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Http\Resources\MenusResource;
use PDF;

class SettingsController extends Controller
{
    //

    protected $repository;

    public function __construct(UserRepository $repository)
    {
        $this->repository = $repository;
    }

    public function getRoles(){
        $roles = Roles::get();
        return response()->json([
            'status'    => true,
            'data'      => $roles,
        ], 200);
    }

    public function index(){
        $settings = Settings::firstorfail();
        return response()->json($settings);
    }


    public function getProfile()
    {
        $user = Accounts::whereId(Auth()->user()->id)->first();

        if (!$user) {
            return response()->json([
                'message'   => 'No Content!',
            ], 204);
        }


        return response()->json([
            'status'    => true,
            'message'   => 'Data berhasil diambil!',
            'data'      => new UserResource($user)
        ], 200);

        // list($code, $data) = $this->repository->getData($id);
        // return ($code == 200) ? new UserResource($data) : response()->json($data, $code);
    }

    public function profile(Request $request)
    {
        $this->validate($request, [
            'name'      => 'required|max:100',
            'email'     => 'required|max:100',
            'username'  => 'required|max:100',
            'foto'      => 'mimes:jpg,png,jpeg|max:4096',
        ]);

        // Get user
        $user = Accounts::whereId(Auth()->user()->id)->first();

        DB::beginTransaction();

        try {

            if ($request->hasFile('foto')) {
                # code...
                Storage::disk('local')->delete('public/users/' . Auth()->user()->id . '/' . basename($user->foto));

                $foto = $request->file('foto');
                $foto->storeAs('public/users/' . Auth()->user()->id , $foto->hashName());
                $user->foto = $foto->hashName();
            }
            $user->update([
                'name'          => $request->name,
                'email'         => $request->email,
                'username'      => $request->username,
            ]);

            $user->save();
        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }

        DB::commit();
        return response()->json([
            'success'   => true,
            'message'   => 'Data User Berhasil diupdate!',
            'data'      => $user,
        ], 201);
    }

    public function search(Request $request)
    {
        if ($request->q) {
            $result = Accounts::with('roles')
            ->where('name', 'LIKE', "%{$request->q}%")
            ->orWhere('email', 'LIKE', "%{$request->q}%")
            ->orWhere('username', 'LIKE', "%{$request->q}%")
            ->orWhere('role_id', 'LIKE', "%{$request->q}%")
            ->get();
        }

        if ($request->c) {
            $result = Accounts::with('roles')
            ->whereHas('roles', function($q) use($request) {
                $q->where('name', $request->c);
            })->get();
        }
            return response()->json($result);

        // return SearchResource::collection($result);
    }

    public function userExport(Request $request)
    {

        if ($request->filter != 0) {
            $users = Accounts::with('roles')->where('role_id', $request->filter)->get();
        } else {
            $users = Accounts::with('roles')->get();
        }
        // $users = Accounts::get();
        $pdf = PDF::loadView('userexport', compact('users'))->setPaper('a4', '');
        Storage::put('public/pdf/User-Table-Dukcapil-' . Carbon::now()->toDateString() . '.pdf', $pdf->output());
        return  $pdf->download('User-Table-Dukcapil-' . Carbon::now()->toDateString() . '.pdf');
    }

    public function menuExport()
    {
        $menus = Menus::with('roles')->get();

        $pdf = PDF::loadView('menuexport', compact('menus'))->setPaper('a4', 'potrait');
        Storage::put('public/pdf/Portal-Tableau-Dukcapil-' . Carbon::now()->toDateString() .'.pdf', $pdf->output());
        return  $pdf->download('Portal-Tableau-Dukcapil-' . Carbon::now()->toDateString() .'.pdf');
        // return response()->json($menus);

        // return view('menuexport', compact('menus'));
    }

    public function alluser()
    {
        # code...
        $users = Accounts::get();

        return response()->json($users);
    }

}
